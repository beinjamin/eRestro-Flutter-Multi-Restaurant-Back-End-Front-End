<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <!-- Main content -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h4>Payment Methods Settings</h4>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?= base_url('admin/home') ?>">Home</a>
                        </li>
                        <li class="breadcrumb-item active">Payment Methods Settings</li>
                    </ol>
                </div>
            </div>
        </div>
        <!-- /.container-fluid -->
    </section>
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card card-info">
                        <form class="form-horizontal form-submit-event" action="<?= base_url('admin/Payment_settings/update_payment_settings'); ?>" method="POST" id="payment_setting_form" enctype="multipart/form-data">
                            <div class="card-body">
                                <div class="row">
                                    <div class="form-group col-md-4">
                                        <label for="paypal_payment_method">Paypal Payments <small>[ Enable / Disable ] </small>
                                        </label>
                                        <div class="card-body">
                                            <input type="checkbox" name="paypal_payment_method" <?= (@$settings['paypal_payment_method']) == '1' ? 'Checked' : '' ?> data-bootstrap-switch data-off-color="danger" data-on-color="success">
                                        </div>
                                    </div>
                                    <div class="form-group col-md-4">
                                        <label for="">Payment Mode <small>[ sandbox / live ]</small>
                                        </label>
                                        <select name="paypal_mode" class="form-control" required>
                                            <option value="">Select Mode</option>
                                            <option value="sandbox" <?= (isset($settings['paypal_mode']) && $settings['paypal_mode'] == 'sandbox') ? 'selected' : '' ?>>Sandbox ( Testing )</option>
                                            <option value="production" <?= (isset($settings['paypal_mode']) && $settings['paypal_mode'] == 'production') ? 'selected' : '' ?>>Production ( Live )</option>
                                        </select>
                                    </div>
                                    <div class="form-group col-md-4">
                                        <label for="paypal_business_email">Paypal Business Email</label>
                                        <input type="text" class="form-control" name="paypal_business_email" value="<?= (isset($settings['paypal_mode'])) ? $settings['paypal_business_email'] : '' ?>" placeholder="Paypal Business Email" />
                                    </div>
                                    <div class="form-group col-md-6">
                                        <label for="currency_code">Currency code</label>
                                        <select class="form-control" name="currency_code" value="<?= @$settings['currency_code'] ?>">
                                            <option value="AUD" <?= (isset($settings["currency_code"]) && $settings["currency_code"] == "AUD") ? "selected" : '' ?>>AUD</option>
                                            <option value="BRL" <?= (isset($settings["currency_code"]) && $settings["currency_code"] == "BRL") ? "selected" : '' ?>>BRL</option>
                                            <option value="CAD" <?= (isset($settings["currency_code"]) && $settings["currency_code"] == "CAD") ? "selected" : '' ?>>CAD</option>
                                            <option value="CNY" <?= (isset($settings["currency_code"]) && $settings["currency_code"] == "CNY") ? "selected" : '' ?>>CNY</option>
                                            <option value="CZK" <?= (isset($settings["currency_code"]) && $settings["currency_code"] == "CZK") ? "selected" : '' ?>>CZK</option>
                                            <option value="DKK" <?= (isset($settings["currency_code"]) && $settings["currency_code"] == "DKK") ? "selected" : '' ?>>DKK</option>
                                            <option value="EUR" <?= (isset($settings["currency_code"]) && $settings["currency_code"] == "EUR") ? "selected" : '' ?>>EUR</option>
                                            <option value="HKD" <?= (isset($settings["currency_code"]) && $settings["currency_code"] == "HKD") ? "selected" : '' ?>>HKD</option>
                                            <option value="HUF" <?= (isset($settings["currency_code"]) && $settings["currency_code"] == "HUF") ? "selected" : '' ?>>HUF</option>
                                            <option value="INR" <?= (isset($settings["currency_code"]) && $settings["currency_code"] == "INR") ? "selected" : '' ?>>INR</option>
                                            <option value="ILS" <?= (isset($settings["currency_code"]) && $settings["currency_code"] == "ILS") ? "selected" : '' ?>>ILS</option>
                                            <option value="JPY" <?= (isset($settings["currency_code"]) && $settings["currency_code"] == "JPY") ? "selected" : '' ?>>JPY</option>
                                            <option value="MYR" <?= (isset($settings["currency_code"]) && $settings["currency_code"] == "MYR") ? "selected" : '' ?>>MYR</option>
                                            <option value="MXN" <?= (isset($settings["currency_code"]) && $settings["currency_code"] == "MXN") ? "selected" : '' ?>>MXN</option>
                                            <option value="TWD" <?= (isset($settings["currency_code"]) && $settings["currency_code"] == "TWD") ? "selected" : '' ?>>TWD</option>
                                            <option value="NZD" <?= (isset($settings["currency_code"]) && $settings["currency_code"] == "NZD") ? "selected" : '' ?>>NZD</option>
                                            <option value="NOK" <?= (isset($settings["currency_code"]) && $settings["currency_code"] == "NOK") ? "selected" : '' ?>>NOK</option>
                                            <option value="PHP" <?= (isset($settings["currency_code"]) && $settings["currency_code"] == "PHP") ? "selected" : '' ?>>PHP</option>
                                            <option value="PLN" <?= (isset($settings["currency_code"]) && $settings["currency_code"] == "PLN") ? "selected" : '' ?>>PLN</option>
                                            <option value="GBP" <?= (isset($settings["currency_code"]) && $settings["currency_code"] == "GBP") ? "selected" : '' ?>>GBP</option>
                                            <option value="RUB" <?= (isset($settings["currency_code"]) && $settings["currency_code"] == "RUB") ? "selected" : '' ?>>RUB</option>
                                            <option value="SGD" <?= (isset($settings["currency_code"]) && $settings["currency_code"] == "SGD") ? "selected" : '' ?>>SGD</option>
                                            <option value="SEK" <?= (isset($settings["currency_code"]) && $settings["currency_code"] == "SEK") ? "selected" : '' ?>>SEK</option>
                                            <option value="CHF" <?= (isset($settings["currency_code"]) && $settings["currency_code"] == "CHF") ? "selected" : '' ?>>CHF</option>
                                            <option value="THB" <?= (isset($settings["currency_code"]) && $settings["currency_code"] == "THB") ? "selected" : '' ?>>THB</option>
                                            <option value="USD" <?= (isset($settings["currency_code"]) && $settings["currency_code"] == "USD") ? "selected" : '' ?>>USD</option>
                                        </select>
                                    </div>
                                    <div class="form-group col-md-6">
                                        <label>Notification URL <small>(Set this as IPN notification URL in you PayPal account)</small></label>
                                        <input type="text" class="form-control" readonly value="<?=base_url('app/v1/api/ipn')?>" />
                                    </div>
                                </div>
                                <!-- <h5>PayUMoney Payments </h5>
                                <hr>
                                <div class="row">
                                    <div class="form-group col-md-6">
                                        <label for="payumoney_payment_method">PayUMoney Payments <small>[ Enable / Disable ] </small>
                                        </label>
                                        <div class="card-body">
                                            <input type="checkbox" name="payumoney_payment_method" <?= (@$settings['payumoney_payment_method']) == '1' ? 'Checked' : '' ?> data-bootstrap-switch data-off-color="danger" data-on-color="success">
                                        </div>
                                    </div>
                                    <div class="form-group col-md-6">
                                        <label for="">Payment Mode <small>[ sandbox / live ]</small>
                                        </label>
                                        <select name="payumoney_mode" class="form-control" required>
                                            <option value="">Select Mode</option>
                                            <option value="sandbox" selected <?= (@$settings['payumoney_mode'] == 'sandbox') ? 'selected' : '' ?>>Sandbox ( Testing )</option>
                                            <option value="production" <?= (@$settings['payumoney_mode'] == 'production') ? 'selected' : '' ?>>Production ( Live )</option>
                                        </select>
                                    </div>
                                    <div class="form-group col-md-4">
                                        <label for="payumoney_merchant_key">Merchant key</label>
                                        <input type="text" class="form-control" name="payumoney_merchant_key" value="<?= @$settings['payumoney_merchant_key'] ?>" placeholder="PayUMoney Merchant Key" />
                                    </div>
                                    <div class="form-group col-md-4">
                                        <label for="payumoney_merchant_id">Merchant ID</label>
                                        <input type="text" class="form-control" name="payumoney_merchant_id" value="<?= @$settings['payumoney_merchant_id'] ?>" placeholder="PayUMoney Merchant ID" />
                                    </div>
                                    <div class="form-group col-md-4">
                                        <label for="payumoney_salt">Salt</label>
                                        <input type="text" class="form-control" name="payumoney_salt" value="<?= @$settings['payumoney_salt'] ?>" placeholder="PayUMoney Merchant ID" />
                                    </div>
                                </div> -->

                                <h5>Razorpay Payments </h5>
                                <hr>
                                <div class="row">
                                    <div class="form-group col-md-4">
                                        <label for="razorpay_payment_method">Razorpay Payments <small>[ Enable / Disable ] </small>
                                        </label>
                                        <br>
                                        <div class="card-body">
                                            <input type="checkbox" name="razorpay_payment_method" <?= (@$settings['razorpay_payment_method']) == '1' ? 'Checked' : '' ?> data-bootstrap-switch data-off-color="danger" data-on-color="success">
                                        </div>
                                    </div>
                                    <div class="form-group col-md-4">
                                        <label for="razorpay_key_id">Razorpay key ID</label>
                                        <input type="text" class="form-control" name="razorpay_key_id" value="<?= @$settings['razorpay_key_id'] ?>" placeholder="Razor Key ID" />
                                    </div>
                                    <div class="form-group col-md-4">
                                        <label for="razorpay_secret_key">Secret Key</label>
                                        <input type="text" class="form-control" name="razorpay_secret_key" value="<?= @$settings['razorpay_secret_key'] ?>" placeholder="Razorpay Secret Key " />
                                    </div>
                                </div>

                                <h5>Paystack Payments </h5>
                                <hr>
                                <div class="row">
                                    <div class="form-group col-md-4">
                                        <label for="paystack_payment_method">Paystack Payments <small>[ Enable / Disable ] </small>
                                        </label>
                                        <br>
                                        <div class="card-body">
                                            <input type="checkbox" name="paystack_payment_method" <?= (@$settings['paystack_payment_method']) == '1' ? 'Checked' : '' ?> data-bootstrap-switch data-off-color="danger" data-on-color="success">
                                        </div>
                                    </div>
                                    <div class="form-group col-md-4">
                                        <label for="paystack_key_id">Paystack key ID</label>
                                        <input type="text" class="form-control" name="paystack_key_id" value="<?= @$settings['paystack_key_id'] ?>" placeholder="Paystack Public Key" />
                                    </div>
                                    <div class="form-group col-md-4">
                                        <label for="paystack_secret_key">Secret Key</label>
                                        <input type="text" class="form-control" name="paystack_secret_key" value="<?= @$settings['paystack_secret_key'] ?>" placeholder="Paystack Secret Key " />
                                    </div>
                                </div>

                                <!-- <h5>Flutterwave Payments </h5>
                                <hr>
                                <div class="row">
                                    <div class="form-group col-md-4">
                                        <label for="flutterwave_payment_method">Flutterwave Payments <small>[ Enable / Disable ] </small>
                                        </label>
                                        <br>
                                        <div class="card-body">
                                            <input type="checkbox" name="flutterwave_payment_method" <?= (@$settings['flutterwave_payment_method']) == '1' ? 'Checked' : '' ?> data-bootstrap-switch data-off-color="danger" data-on-color="success">
                                        </div>
                                    </div>
                                    <div class="form-group col-md-4">
                                        <label for="flutterwave_key_id">Flutterwave key ID</label>
                                        <input type="text" class="form-control" name="flutterwave_key_id" value="<?= @$settings['flutterwave_key_id'] ?>" placeholder="Flutterwave Public Key" />
                                    </div>
                                    <div class="form-group col-md-4">
                                        <label for="flutterwave_secret_key">Secret Key</label>
                                        <input type="text" class="form-control" name="flutterwave_secret_key" value="<?= @$settings['flutterwave_secret_key'] ?>" placeholder="Flutterwave Secret Key " />
                                    </div>
                                    <div class="form-group col-md-4">
                                        <label for="flutterwave_encryption_key">Flutterwave Encryption key</label>
                                        <input type="text" class="form-control" name="flutterwave_encryption_key" value="<?= @$settings['flutterwave_encryption_key'] ?>" placeholder="Flutterwave Encryption Key " />
                                    </div>
                                </div>   -->
                                <h5>Cash On Delivery </h5>
                                <hr>
                                <div class="row">
                                    <div class="form-group col-md-4">
                                        <label for="cod_method">COD <small>[ Enable / Disable ] </small>
                                        </label>
                                        <br>
                                        <div class="card-body">
                                            <input type="checkbox" name="cod_method" <?= (@$settings['cod_method']) == '1' ? 'Checked' : '' ?> data-bootstrap-switch data-off-color="danger" data-on-color="success">
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <button type="reset" class="btn btn-warning">Reset</button>
                                    <button type="submit" class="btn btn-success" id="submit_btn">Update Payment Settings</button>
                                </div>
                            </div>
                            <div class="d-flex justify-content-center">
                                <div class="form-group" id="error_box">
                                </div>
                            </div>
                        </form>
                    </div>
                    <!--/.card-->
                </div>
                <!--/.col-md-12-->
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
</div>