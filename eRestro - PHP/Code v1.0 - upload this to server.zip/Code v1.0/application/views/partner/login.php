<!DOCTYPE html>
<html>
<?php $this->load->view('partner/include-head.php'); ?>

<body class="hold-transition login-page ">
	<?php $this->load->view('partner/pages/' . $main_page); ?>
	<!-- Footer -->
	<?php $this->load->view('partner/include-script.php'); ?>
</body>

</html>