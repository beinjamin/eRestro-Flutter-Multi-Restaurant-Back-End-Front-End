<html>
	<body>
		<h1>You are added in Company_Name</h1>
		<p>You are added in company_name</p>
		<p>Go To your workspace <a href="#">Click Here</a></p>
	</body>
</html>