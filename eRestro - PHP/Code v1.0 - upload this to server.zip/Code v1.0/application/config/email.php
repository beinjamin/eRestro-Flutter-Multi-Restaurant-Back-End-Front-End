<?php defined('BASEPATH') OR exit('No direct script access allowed');

$config['email_config'] = array();


// 'mailtype' => 'html',
// 'protocol' => 'SMTP',
// 'smtp_crypto' => 'ssl',
// 'smtp_host' => 'smtp.gmail.com',
// 'smtp_port' => '587',
// 'smtp_user' => 'infinitietechnologies01@gmail.com',
// 'smtp_pass' => 'caomvbvzghoazkog',
// 'charset' => 'utf-8',
// 'newline' => '\r\n',
?>